# angryBirdsStage2.5
Angry Birds stage 2.5 with Class Inheritance and Images
